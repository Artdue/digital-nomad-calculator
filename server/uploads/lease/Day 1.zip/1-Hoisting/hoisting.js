// // 1


// console.log({ johnny, suzie });

// sayBye();
// sayHi();

// var johnny = 'Johnny';
// const suzie = 'Suzie';

// var sayHi = function () {
//   console.log('Hi!');
// };

// function sayBye() {
//   console.log('Bye!');
// }

// // 2
// var favoriteFood = 'pizza';

// function foodThoughts() {
//   // favoriteFood: 'sushi'
//   console.log('Old favorite food: ' + favoriteFood);
//   var favoriteFood = 'sushi';
//   console.log('New favorite food: ' + favoriteFood);
//   // New favorite food: sushi
// }

// foodThoughts();
// console.log(favoriteFood);

// // 3

// console.log(y);
// console.log(z);
// console.log(x);

// y = 'y';
// let x = 'x';
// var z = 'z';

// // 4

// console.log(a); // ?
// b(); // ?
// //
// var a = 2;
// var a = 3;
// //
// function b() {
//   console.log('Hello');
// }
// //
// console.log(a); // ?
// b(); // ?
// //
// //
// function b() {
//   console.log('Bye');
// }

// console.log(a); // ?
// b(); // ?
//
// // 5
//
// function hoistingExample() {
//   console.log("Value of a in local scope: ", a);
// }

// console.log("Value of a in global scope: ", a); // a = ?
// var a = 1;
// hoistingExample(); // ?
//
// // 6

// function hoist() {
//   var a = 1;
// }

// hoist();
// console.log(a); // ?
//
// // 7

// console.log({ showName, print });

// var showName = function print(name) {
//   console.log(name);
// };
